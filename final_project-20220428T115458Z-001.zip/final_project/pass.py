import itertools as its
words="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890"
dic = open("pass.txt","w")
#r=its.product(words,repeat=1)
for x in range(1,7):
    r=its.product(words,repeat=x)
    for i in r:
        dic.writelines("".join(i))
        dic.write("\n")
dic.close()