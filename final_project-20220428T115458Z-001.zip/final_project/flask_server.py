# 簡單登入接口

from flask import Flask
from flask import request
from flask import redirect
from flask import current_app

app = Flask(__name__)

user = input("set user:")  # 初始化使用者帳號
passwd = input("set password:")  # 初始化使用者密碼


@app.route('/user/login', methods=['GET'])
def start():

    # flask 獲得 GET 参數
    username = request.args.get('username')
    password = request.args.get('password')

    if username == user:
        if password == passwd:
            return 'login success'
        else:
            return 'login fail'
    else:
        return 'no exist user'


if __name__ == '__main__':
    app.run()
